# TP N°1  Especificacion y WP :

###  Algoritmo y Estructuras de Datos

Presentación: viernes 5/4.\
Entrega: sábado 20/4.\
Recursos: https://www.overleaf.com/ 





